package com.lesson.entity;

public class Profession {

    private String pro_id;
    private String school_id;
    private String pro_name;

    public Profession() {
    }

    public Profession(String pro_id, String school_id, String prn_name) {
        this.pro_id = pro_id;
        this.school_id = school_id;
        this.pro_name = prn_name;
    }

    public String getPro_id() {
        return pro_id;
    }

    public void setPro_id(String pro_id) {
        this.pro_id = pro_id;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getPro_name() {
        return pro_name;
    }

    public void setPro_name(String pro_name) {
        this.pro_name = pro_name;
    }

    @Override
    public String toString() {
        return "Profession{" +
                "pro_id='" + pro_id + '\'' +
                ", school_id='" + school_id + '\'' +
                ", prn_name='" + pro_name + '\'' +
                '}';
    }
}
