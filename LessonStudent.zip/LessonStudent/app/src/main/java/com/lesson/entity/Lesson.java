package com.lesson.entity;

public class Lesson {
    private String les_id;
    private String les_name;
    private String school_id;
    private String pro_id;

    public Lesson() {
    }

    public Lesson(String les_id, String les_name, String school_id, String pro_id) {
        this.les_id = les_id;
        this.les_name = les_name;
        this.school_id = school_id;
        this.pro_id = pro_id;
    }

    public String getLes_id() {
        return les_id;
    }

    public void setLes_id(String les_id) {
        this.les_id = les_id;
    }

    public String getLes_name() {
        return les_name;
    }

    public void setLes_name(String les_name) {
        this.les_name = les_name;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getPro_id() {
        return pro_id;
    }

    public void setPro_id(String pro_id) {
        this.pro_id = pro_id;
    }

    @Override
    public String toString() {
        return "Lesson{" +
                "les_id='" + les_id + '\'' +
                ", les_name='" + les_name + '\'' +
                ", school_id='" + school_id + '\'' +
                ", pro_id='" + pro_id + '\'' +
                '}';
    }
}
