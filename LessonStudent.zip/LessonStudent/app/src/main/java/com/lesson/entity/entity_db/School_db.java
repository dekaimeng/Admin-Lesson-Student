package com.lesson.entity.entity_db;

import com.lesson.entity.Profession;

import java.util.List;


public class School_db {

    private String school_id;
    private String school_name;
    private String school_position;

    private List<Profession> professions;

    public School_db() {
    }

    public School_db(String school_id, String school_name, String school_position, List<Profession> professions) {
        this.school_id = school_id;
        this.school_name = school_name;
        this.school_position = school_position;
        this.professions = professions;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getSchool_name() {
        return school_name;
    }

    public void setSchool_name(String school_name) {
        this.school_name = school_name;
    }

    public String getSchool_position() {
        return school_position;
    }

    public void setSchool_position(String school_position) {
        this.school_position = school_position;
    }

    public List<Profession> getProfessions() {
        return professions;
    }

    public void setProfessions(List<Profession> professions) {
        this.professions = professions;
    }

    @Override
    public String toString() {
        return "School_db{" +
                "school_id='" + school_id + '\'' +
                ", school_name='" + school_name + '\'' +
                ", school_position='" + school_position + '\'' +
                ", professions=" + professions +
                '}';
    }
}
