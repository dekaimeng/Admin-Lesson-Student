package com.lesson.entity;

/**
 * 地点 实体类
 */
public class School {
    private String school_id;
    private String school_name;
    private String school_position;

    public School() {
    }

    public School(String school_id, String school_name, String school_position) {
        this.school_id = school_id;
        this.school_name = school_name;
        this.school_position = school_position;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getSchool_name() {
        return school_name;
    }

    public void setSchool_name(String school_name) {
        this.school_name = school_name;
    }

    public String getSchool_position() {
        return school_position;
    }

    public void setSchool_position(String school_position) {
        this.school_position = school_position;
    }

    @Override
    public String toString() {
        return "School{" +
                "school_id='" + school_id + '\'' +
                ", school_name='" + school_name + '\'' +
                ", school_position='" + school_position + '\'' +
                '}';
    }
}
