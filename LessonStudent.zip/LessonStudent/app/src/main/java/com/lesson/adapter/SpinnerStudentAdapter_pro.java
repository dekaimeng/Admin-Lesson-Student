package com.lesson.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.lesson.entity.Profession;
import com.lesson.lessonstudent.R;

import java.util.List;



public class SpinnerStudentAdapter_pro extends BaseAdapter {

    private List<Profession> list;
    private Context context;

//    private static HashMap isSelectedMap;
//    private static HashMap isVisibileMap;

    public SpinnerStudentAdapter_pro() {

    }

    //Construction method
    public SpinnerStudentAdapter_pro(List list, Context context) {
        this.list = list;
        this.context = context;

    }

    @Override
    public int getCount() {
        int number = 0;
        if (list != null) {
            number = list.size();
        }
        return number;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }


    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

//    public void updateItemsData(List<String> list){
//        this.list = list;
//        notifyDataSetChanged();
//    }

    //This method needs to be called once for each item in the listview list
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        view=layoutInflater.inflate(R.layout.activity_select_item_profession,null);
        if (view != null) {
            TextView textView=view.findViewById(R.id.textView_id);
            textView.setText(list.get(i).getPro_name());

        }
        return view;
    }

}
