package com.lesson.entity;

public class Student_Lesson {

    private String sl_id;
    private String stu_id;
    private String les_id;

    public Student_Lesson() {
    }

    public Student_Lesson(String sl_id, String stu_id, String les_id) {
        this.sl_id = sl_id;
        this.stu_id = stu_id;
        this.les_id = les_id;
    }

    public String getStu_id() {
        return stu_id;
    }

    public void setStu_id(String stu_id) {
        this.stu_id = stu_id;
    }

    public String getLes_id() {
        return les_id;
    }

    public void setLes_id(String les_id) {
        this.les_id = les_id;
    }

    public String getSl_id() {
        return sl_id;
    }

    public void setSl_id(String sl_id) {
        this.sl_id = sl_id;
    }

    @Override
    public String toString() {
        return "Student_Lesson{" +
                "sl_id='" + sl_id + '\'' +
                ", stu_id='" + stu_id + '\'' +
                ", les_id='" + les_id + '\'' +
                '}';
    }
}
