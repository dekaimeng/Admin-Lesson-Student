package com.lesson.adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.lesson.entity.Lesson;
import com.lesson.lessonstudent.R;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Adapter for course list
 */
public class ListViewHome_LessonAdapter extends BaseAdapter {
    private List<Lesson> list;
    private LayoutInflater inflater;
    //    private RecyclerView.ViewHolder viewHolder;
    private static HashMap isSelectedMap;
    private static HashMap isVisibileMap;

//    private CollectionReference cr_sch = FirebaseFirestore.getInstance().collection("schools");
//    private CollectionReference cr_pro = FirebaseFirestore.getInstance().collection("professions");

    public ListViewHome_LessonAdapter() {

    }

    //Construction method
    public ListViewHome_LessonAdapter(List list, LayoutInflater inflater) {
        this.list = list;
        this.inflater = inflater;
        System.out.println(list.toString());
        isSelectedMap = new HashMap();
        isVisibileMap = new HashMap();
        initDate();
    }

    //Initialize the map and assign the default value to the map. When it is needed, it is convenient to modify it directly
    private void initDate() {
        for (int i = 0; i < list.size(); i++) {
            getIsSelectedMap().put(i, false);
            getIsVisibileMap().put(i, CheckBox.INVISIBLE);
        }
    }

    @Override
    public int getCount() {
        int number = 0;
        if (list != null) {
            number = list.size();
        }
        return number;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }


    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public LayoutInflater getInflater() {
        return inflater;
    }

    public void setInflater(LayoutInflater inflater) {
        this.inflater = inflater;
    }

//    public RecyclerView.ViewHolder getViewHolder() {
//        return viewHolder;
//    }

//    public void setViewHolder(RecyclerView.ViewHolder viewHolder) {
//        this.viewHolder = viewHolder;
//    }


    public HashMap getIsSelectedMap() {
        return isSelectedMap;
    }

    public void setIsSelectedMap(HashMap isSelectedMap) {
        this.isSelectedMap = isSelectedMap;
    }

    public HashMap getIsVisibileMap() {
        return isVisibileMap;
    }

    public void setIsVisibileMap(HashMap isVisibileMap) {
        this.isVisibileMap = isVisibileMap;
    }

    //Used to store controls
    public final class ViewHolder {
        public TextView textView1;

        //        public TextView textView5;
        public CheckBox checkBox;
    }


    //This method needs to be called once for each item in the listview list
    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        final ViewHolder[] viewHolder = new ViewHolder[1];

        if (view == null) {
            view = inflater.inflate(
                    R.layout.list_item_lesson, null

            );
            //Instantiate control based on ID
            viewHolder[0] = new ViewHolder();
            viewHolder[0].textView1 = (TextView) view
                    .findViewById(R.id.text_lesson_name_home);

            viewHolder[0].checkBox = (CheckBox) view
                    .findViewById(R.id.checkbox_list_item_home_lesson);

            final int p = i;
            viewHolder[0].checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    CheckBox c = (CheckBox) view;
                    if (!(c.isChecked() && (boolean) getIsSelectedMap().get(p))) {
                        getIsSelectedMap().remove(p);
                        getIsSelectedMap().put(p, c.isChecked());
                    }

                }
            });

            view.setTag(viewHolder[0]);
        } else {
            viewHolder[0] = (ViewHolder) view.getTag();
        }

        final View finalView = view;
        //Assign values to controls
        viewHolder[0].textView1.setText(list.get(i).getLes_name());
        viewHolder[0] = (ViewHolder) finalView.getTag();
        //Set properties for the check box
        viewHolder[0].checkBox.setChecked((Boolean) getIsSelectedMap().get(i));
        viewHolder[0].checkBox.setVisibility((Integer) getIsVisibileMap().get(i));


        return view;
    }


}


