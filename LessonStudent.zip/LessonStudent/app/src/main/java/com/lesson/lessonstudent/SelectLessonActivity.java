package com.lesson.lessonstudent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.lesson.adapter.SpinnerStudentAdapter;
import com.lesson.adapter.SpinnerStudent_LessonAdapter;
import com.lesson.entity.Lesson;
import com.lesson.entity.Profession;
import com.lesson.entity.School;
import com.lesson.entity.StuUser;
import com.lesson.entity.Student;
import com.lesson.entity.Student_Lesson;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SelectLessonActivity extends AppCompatActivity {

    private SharedPreferences mPref;
    private Spinner spinner_lesson;
    private Button btn_add;
    private Button btn_back;

    private StuUser stuUser;
    private Student student;

    private Cursor cursor_student;
    private Cursor cursor_stu_les;
    private Cursor cursor_lesson;
    private List<Lesson> lessons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_lesson);

        init();
        initData();
        loadData();
        spinnerss();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SelectLessonActivity.this,StudentMainActivity.class));
            }
        });
    }
    /**
     * Initializing global objects
     *
     */
    private void init() {
        spinner_lesson = findViewById(R.id.spin_lesson_student);
        btn_add = findViewById(R.id.btn_lesson_add);
        btn_back=findViewById(R.id.btn_lesson_back);
        lessons = new ArrayList<>();
        mPref = getSharedPreferences("stuUser_data", MODE_PRIVATE);
        //Get the judgment of the file. If there is corresponding content in the file, the content will be returned; if not, the user will not exist
        stuUser = new StuUser(mPref.getString("stuu_id", "wrong"),
                mPref.getString("stuu_username", "wrong"),
                mPref.getString("stuu_password", "wrong"),
                mPref.getString("stu_id", "wrong")
               );
    }
    /**
     * Initializing data for global objects
     */
    private void initData() {
        ContentResolver resolver = getContentResolver();

        Uri uri = Uri.parse("content://provider.lessonProvider/lesson/");
        cursor_lesson = resolver.query(uri, null, null, null, null, null);

        uri = Uri.parse("content://provider.studentProvider/student/");
        cursor_student = resolver.query(uri, null, null, null, null, null);

    }

    /**
     * Load data
     */
    private void loadData() {

        if (cursor_student!=null && cursor_student.moveToFirst()){
            do {
                if (cursor_student.getString(0).equals(stuUser.getStu_id())) {
                    student = new Student(cursor_student.getString(0),
                            cursor_student.getString(1),
                            cursor_student.getString(2),
                            cursor_student.getString(3),
                            cursor_student.getString(4),
                            cursor_student.getString(5));
                }
            }while (cursor_student.moveToNext());
        }

        if (cursor_lesson!=null && cursor_lesson.moveToFirst()){
            do {
                if (student.getSchool_id().equals(cursor_lesson.getString(2))
                        &&student.getPro_id().equals(cursor_lesson.getString(3))){

                    lessons.add(new Lesson(cursor_lesson.getString(0),
                            cursor_lesson.getString(1),
                            cursor_lesson.getString(2),
                            cursor_lesson.getString(3)));
                }
            }while (cursor_lesson.moveToNext());
        }
    }
    /**
     * Configuring the first drop-down box for course management
     */
    private void spinnerss() {
        //Instantiation of Adapter
        SpinnerStudent_LessonAdapter adapter = new SpinnerStudent_LessonAdapter(lessons, this);
        // Configure Adapter for listView
        spinner_lesson.setAdapter(adapter);
        //Set selected events to listView
        spinner_lesson.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                btn_add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Student_Lesson student_lesson=new Student_Lesson(UUID.randomUUID().toString(),
                                stuUser.getStu_id(),
                                lessons.get(position).getLes_id());

                        Uri uri = Uri.parse("content://provider.student_LessonProvider/student_lesson/");
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put("sl_id", student_lesson.getSl_id());
                        values.put("stu_id",student_lesson.getStu_id());
                        values.put("les_id",student_lesson.getLes_id());

                        resolver.insert(uri, values);

                        //Display new success information
                        Toast.makeText(getApplicationContext(), "Add Successed", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}
