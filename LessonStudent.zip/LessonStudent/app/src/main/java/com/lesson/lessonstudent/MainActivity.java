package com.lesson.lessonstudent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.lesson.entity.StuUser;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private Button btn_regist;
    private Button btn_login;
    private EditText editText_username;
    private EditText editText_password;
    private SharedPreferences mPref;
    private SharedPreferences.Editor mEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Hide the head of the app
        this.getSupportActionBar().hide();

        init();
        btn_regist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jump to the registration interface from the current page
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });


    }

    private void login() {
        //Create an XML file -- an XML file named adminuser data: used to store the user name, password and ID after login
        mPref = getSharedPreferences("stuUser_data", MODE_PRIVATE);
        mEditor = mPref.edit();

        String username = editText_username.getText().toString();
        StuUser stuUser = new StuUser(null,
                editText_username.getText().toString(),
                editText_password.getText().toString(),
                null);
        ContentResolver resolver = getContentResolver();
        Uri uri = Uri.parse("content://provider.stuuProvider/stuu/");
        Cursor cursor = resolver.query(uri, null, null, null, null, null);
        boolean judge=false;
        if (cursor!=null && cursor.moveToFirst()){
            do {
                if (cursor.getString(1).equals(stuUser.getStuu_username())) {
                    judge=true;

                    System.out.println(cursor.getString(1));
                    if (cursor.getString(2).equals(stuUser.getStuu_password())) {

                        stuUser.setStuu_id(cursor.getString(0));
                        stuUser.setStu_id(cursor.getString(3));
                        //The pop-up window shows the successful login information
                        Toast.makeText(getApplicationContext(), "Login succeeded", Toast.LENGTH_SHORT).show();
                        //Store the login data in an XML file
                        mEditor.putString("stuu_username", stuUser.getStuu_username());
                        mEditor.putString("stuu_password", stuUser.getStuu_password());
                        mEditor.putString("stuu_id", stuUser.getStuu_id());
                        mEditor.putString("stu_id", stuUser.getStu_id());
                        mEditor.commit();
                        cursor.moveToFirst();
                        cursor.close();
                        if (stuUser.getStu_id().equals("")){
                            startActivity(new Intent(MainActivity.this,StudentRegistActivity .class));
                        }else {
                            startActivity(new Intent(MainActivity.this, StudentMainActivity.class));
                        }
                        break;
                    }else {
                        judge=false;
                        editText_password.setError("Wrong Password");
                    }
                }
            }while (cursor.moveToNext());
        }

        if (!judge){
            editText_username.setError("Wrong Username");
        }
    }

    private void init() {
        btn_login = findViewById(R.id.btn_login);
        btn_regist = findViewById(R.id.btn_regist);
        editText_username = findViewById(R.id.username);
        editText_password = findViewById(R.id.password);
    }


}
