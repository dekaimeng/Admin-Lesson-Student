package com.lesson.entity;

public class Student {
    private String stu_id;
    private String stu_name;
    private String stu_gender;
    private String stu_phone;
    private String school_id;
    private String pro_id;
//    private String[] les_ids;  335h9

    public Student() {
    }

    public Student(String stu_id, String stu_name, String stu_gender, String stu_phone, String school_id, String pro_id) {
        this.stu_id = stu_id;
        this.stu_name = stu_name;
        this.stu_gender = stu_gender;
        this.stu_phone = stu_phone;
        this.school_id = school_id;
        this.pro_id = pro_id;
    }

//    public Student(String stu_id, String stu_name, String stu_gender, String stu_phone, String school_id, String pro_id, String[] les_ids) {
//        this.stu_id = stu_id;
//        this.stu_name = stu_name;
//        this.stu_gender = stu_gender;
//        this.stu_phone = stu_phone;
//        this.school_id = school_id;
//        this.pro_id = pro_id;
//        this.les_ids = les_ids;
//    }

    public String getStu_id() {
        return stu_id;
    }

    public void setStu_id(String stu_id) {
        this.stu_id = stu_id;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getStu_gender() {
        return stu_gender;
    }

    public void setStu_gender(String stu_gender) {
        this.stu_gender = stu_gender;
    }

    public String getStu_phone() {
        return stu_phone;
    }

    public void setStu_phone(String stu_phone) {
        this.stu_phone = stu_phone;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getPro_id() {
        return pro_id;
    }

    public void setPro_id(String pro_id) {
        this.pro_id = pro_id;
    }

}
