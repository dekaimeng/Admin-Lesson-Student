package com.lesson.lessonstudent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


import com.lesson.adapter.SpinnerStudentAdapter;
import com.lesson.adapter.SpinnerStudentAdapter_pro;
import com.lesson.entity.Profession;
import com.lesson.entity.School;
import com.lesson.entity.StuUser;
import com.lesson.entity.Student;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class StudentRegistActivity extends AppCompatActivity {

    private SharedPreferences mPref;
    private SharedPreferences.Editor mEditor;

    private Button btn_add;
    private EditText editText_name;
    private EditText editText_gender;
    private EditText editText_phone;
    private Spinner spinner_school;
    private Spinner spinner_profession;
    private Cursor cursor_school;
    private Cursor cursor_profession;
    private List<School> schools;
    private List<Profession> professions;
    private List<Map<Object, List>> mapList;
    private StuUser stuUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_regist);

        init();
        initData_spin();
        loadData();
        spinnerss();
    }

    /**
     * Initializing global objects
     */
    private void init() {
        btn_add = findViewById(R.id.btn_student_add);
        editText_name = findViewById(R.id.edit_student_name);
        editText_gender = findViewById(R.id.edit_student_gender);
        editText_phone = findViewById(R.id.edit_student_phone);
        spinner_school = findViewById(R.id.spin_school_student);
        spinner_profession = findViewById(R.id.spin_profession_student);
        schools = new ArrayList<>();
        professions = new ArrayList<>();
        mapList = new ArrayList<>();
        mPref = getSharedPreferences("stuUser_data", MODE_PRIVATE);
        //Get the judgment of the file. If there is corresponding content in the file, the content will be returned; if not, the user will not exist
        stuUser = new StuUser(mPref.getString("stuu_id", "wrong"),
                mPref.getString("stuu_username", "wrong"),
                mPref.getString("stuu_password", "wrong"),
                mPref.getString("stu_id", "wrong")
        );
        mEditor = mPref.edit();
    }

    /**
     * Initializing data for global objects
     */
    private void initData_spin() {
        ContentResolver resolver = getContentResolver();

        Uri uri = Uri.parse("content://provider.schoolProvider/school/");
        cursor_school = resolver.query(uri, null, null, null, null, null);

        uri = Uri.parse("content://provider.professionProvider/profession/");
        cursor_profession = resolver.query(uri, null, null, null, null, null);
    }

    /**
     * load Data
     */
    private void loadData() {
        if (cursor_school != null && cursor_school.moveToFirst()) {
            do {
                School school = new School(cursor_school.getString(0),
                        cursor_school.getString(1),
                        cursor_school.getString(2));
                schools.add(school);
            } while (cursor_school.moveToNext());
        }

        if (cursor_profession != null && cursor_profession.moveToFirst()) {
            do {
                Profession profession = new Profession(cursor_profession.getString(0),
                        cursor_profession.getString(1),
                        cursor_profession.getString(2));
                professions.add(profession);
            } while (cursor_profession.moveToNext());
        }

        for (School school : schools) {

            Map map = new LinkedHashMap();
            List<Profession> list = new ArrayList<>();
            for (Profession profession : professions) {

                if (school.getSchool_id().equals(profession.getSchool_id())) {

                    list.add(profession);
                }
            }
            map.put(school, list);
            mapList.add(map);
        }
    }

    private void spinnerss() {

        SpinnerStudentAdapter adapter = new SpinnerStudentAdapter(schools, this);

        spinner_school.setAdapter(adapter);

        SpinnerSelectedListener_school spinnerSelectedListener = new SpinnerSelectedListener_school();
        spinner_school.setOnItemSelectedListener(spinnerSelectedListener);

    }

    private class SpinnerSelectedListener_school implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            List professions_SchoolSelected = getProfessions(schools.get(i));
            SpinnerStudentAdapter_pro adapter = new SpinnerStudentAdapter_pro(professions_SchoolSelected, getApplicationContext());
            spinner_profession.setAdapter(adapter);
            SpinnerSelectedListerner_profession spinnerSelectedListerner_profession = new SpinnerSelectedListerner_profession(professions_SchoolSelected);
            spinner_profession.setOnItemSelectedListener(spinnerSelectedListerner_profession);
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    private class SpinnerSelectedListerner_profession implements AdapterView.OnItemSelectedListener {
        private List<Profession> list;

        private SpinnerSelectedListerner_profession(List<Profession> list) {
            this.list = list;
        }

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, final int i, long l) {

            final Profession profession = list.get(i);
            btn_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Student student = new Student(UUID.randomUUID().toString(),
                            editText_name.getText().toString(),
                            editText_gender.getText().toString(),
                            editText_phone.getText().toString(),
                            profession.getSchool_id(), profession.getPro_id());

                    //Determine whether the text is null
                    if (student.getStu_name().equals("")) {
                        editText_name.setError("Cannot be empty");
                    } else {

                        Uri uri = Uri.parse("content://provider.studentProvider/student/");
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put("stu_id", student.getStu_id());
                        values.put("stu_name", student.getStu_name());
                        values.put("stu_gender", student.getStu_gender());
                        values.put("stu_phone", student.getStu_phone());
                        values.put("school_id", student.getSchool_id());
                        values.put("pro_id", student.getPro_id());
                        resolver.insert(uri, values);

                        //update StuUser
                        uri = Uri.parse("content://provider.stuuProvider/stuu/");
                        stuUser.setStu_id(student.getStu_id());
                        values = new ContentValues();
                        values.put("stuu_id", stuUser.getStuu_id());
                        values.put("stu_id", stuUser.getStu_id());
                        values.put("stuu_username", stuUser.getStuu_username());
                        values.put("stuu_password", stuUser.getStuu_password());
                        resolver.update(uri, values, null, null);

                        //Display new success information
                        Toast.makeText(getApplicationContext(), "Added successfully", Toast.LENGTH_SHORT).show();
                        //The input box is set to empty
                        editText_name.setText("");
                        editText_gender.setText("");
                        editText_phone.setText("");

                        mEditor.remove("stu_id");
                        mEditor.putString("stu_id", stuUser.getStu_id());
                        mEditor.commit();
                        startActivity(new Intent(StudentRegistActivity.this, StudentMainActivity.class));
                    }
                }
            });
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    }

    private List getProfessions(School school) {
        List<Profession> profession_res = new ArrayList<>();
        for (Map<Object, List> map : mapList) {
            Set<Object> set = map.keySet();

            for (Object school1 : set) {
                School school2 = (School) school1;
                if (school.getSchool_id().equals(school2.getSchool_id())) {
                    profession_res = map.get(school2);
                }
            }
        }
        return profession_res;
    }
}
