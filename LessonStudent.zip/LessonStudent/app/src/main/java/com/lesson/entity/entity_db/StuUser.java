package com.lesson.entity.entity_db;

public class StuUser {
    private String stuu_id;
    private String stuu_username;
    private String stuu_password;
    private String stu_id;

    public StuUser(String stuu_id, String stuu_username, String stuu_password, String stu_id) {
        this.stuu_id = stuu_id;
        this.stuu_username = stuu_username;
        this.stuu_password = stuu_password;
        this.stu_id = stu_id;
    }

    public StuUser() {
    }

    public String getStuu_id() {
        return stuu_id;
    }

    public void setStuu_id(String stuu_id) {
        this.stuu_id = stuu_id;
    }

    public String getStuu_username() {
        return stuu_username;
    }

    public void setStuu_username(String stuu_username) {
        this.stuu_username = stuu_username;
    }

    public String getStuu_password() {
        return stuu_password;
    }

    public void setStuu_password(String stuu_password) {
        this.stuu_password = stuu_password;
    }

    public String getStu_id() {
        return stu_id;
    }

    public void setStu_id(String stu_id) {
        this.stu_id = stu_id;
    }

    @Override
    public String toString() {
        return "StuUser{" +
                "stuu_id='" + stuu_id + '\'' +
                ", stuu_username='" + stuu_username + '\'' +
                ", stuu_password='" + stuu_password + '\'' +
                ", stu_id='" + stu_id + '\'' +
                '}';
    }
}
