package com.lesson.entity;

public class AdminUser {
    private String adm_uid;
    private String adm_username;
    private String adm_password;

    public AdminUser() {
    }

    public AdminUser(String adm_username, String adm_password) {
        this.adm_username = adm_username;
        this.adm_password = adm_password;
    }

    public AdminUser(String adm_uid, String adm_username, String adm_password) {
        this.adm_uid = adm_uid;
        this.adm_username = adm_username;
        this.adm_password = adm_password;
    }

    public String getAdm_uid() {
        return adm_uid;
    }

    public void setAdm_uid(String adm_uid) {
        this.adm_uid = adm_uid;
    }

    public String getAdm_username() {
        return adm_username;
    }

    public void setAdm_username(String adm_username) {
        this.adm_username = adm_username;
    }

    public String getAdm_password() {
        return adm_password;
    }

    public void setAdm_password(String adm_password) {
        this.adm_password = adm_password;
    }
}
