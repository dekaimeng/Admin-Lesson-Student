package com.lesson.lessonstudent;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.lesson.adapter.ListViewHome_LessonAdapter;
import com.lesson.entity.Lesson;
import com.lesson.entity.Profession;
import com.lesson.entity.School;
import com.lesson.entity.StuUser;
import com.lesson.entity.Student;
import com.lesson.entity.Student_Lesson;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class StudentMainActivity extends AppCompatActivity {

    private SharedPreferences mPref;

    private TextView textView_studentName;
    private TextView textView_addressName;
    private TextView textView_professionName;

    private ListView listView;
    private ListViewHome_LessonAdapter listViewHome_lessonAdapter;

    private Cursor cursor_school;
    private Cursor cursor_student;
    private Cursor cursor_profession;
    private Cursor cursor_lesson;
    private Cursor cursor_student_lesson;

    private AlertDialog alertDialog = null;

    private List<Lesson> lessonList;
    private List<Student_Lesson> student_lessonList;
    List<Lesson> list_listView;
    private Student student;
    private String schoolName;
    private String professionName;

    private Button btn_selectAll;
    private Button btn_update;
    private Button btn_delete;
    private Button btn_cancel;
    private Button btn_addLesson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_main);

        init();
        initData();
        setText();
        listViewSet();

        btn_addLesson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudentMainActivity.this, SelectLessonActivity.class));
            }
        });

        btn_selectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAll();
            }
        });

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update();
            }
        });
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancel();
            }
        });
    }

    /**
     * Initializing global objects
     */
    private void init() {
        textView_studentName = findViewById(R.id.text_studentName);
        textView_addressName = findViewById(R.id.text_addressName);
        textView_professionName = findViewById(R.id.text_professionName);

        btn_selectAll = findViewById(R.id.button1_home_lesson);
        btn_update = findViewById(R.id.button2_home_lesson);
        btn_delete = findViewById(R.id.button3_home_lesson);
        btn_cancel = findViewById(R.id.button4_home_lesson);
        btn_addLesson = findViewById(R.id.btn_lesson_add);

        listView = findViewById(R.id.list_item_home_lesson);

        lessonList = new ArrayList<>();
        student_lessonList = new ArrayList<>();
        student = null;

        ContentResolver resolver = getContentResolver();

        Uri uri = Uri.parse("content://provider.lessonProvider/lesson/");
        cursor_lesson = resolver.query(uri, null, null, null, null, null);

        uri = Uri.parse("content://provider.studentProvider/student/");
        cursor_student = resolver.query(uri, null, null, null, null, null);

        uri = Uri.parse("content://provider.schoolProvider/school/");
        cursor_school = resolver.query(uri, null, null, null, null, null);

        uri = Uri.parse("content://provider.professionProvider/profession/");
        cursor_profession = resolver.query(uri, null, null, null, null, null);

        uri = Uri.parse("content://provider.student_LessonProvider/student_lesson/");
        cursor_student_lesson = resolver.query(uri, null, null, null, null, null);

        mPref = getSharedPreferences("stuUser_data", MODE_PRIVATE);

    }

    /**
     * Initializing data for global objects
     */
    private void initData() {
        //get Students

        if (cursor_student != null && cursor_student.moveToFirst()) {
            do {
                if (cursor_student.getString(0).equals(mPref.getString("stu_id", "wrong"))) {

                    student = new Student(cursor_student.getString(0),
                            cursor_student.getString(1),
                            cursor_student.getString(2),
                            cursor_student.getString(3),
                            cursor_student.getString(4),
                            cursor_student.getString(5));

                    break;
                }
            } while (cursor_student.moveToNext());
        }

        //get Lessons
        if (cursor_lesson != null && cursor_lesson.moveToFirst()) {
            do {
                Lesson lesson = new Lesson(cursor_lesson.getString(0),
                        cursor_lesson.getString(1),
                        cursor_lesson.getString(2),
                        cursor_lesson.getString(3));
                lessonList.add(lesson);
            } while (cursor_lesson.moveToNext());
        }

        if (student != null) {
            //get ProfessionName
            if (cursor_profession != null && cursor_profession.moveToFirst()) {
                do {
                    String id = cursor_profession.getString(0);
                    if (student.getPro_id().equals(id)) {
                        professionName = cursor_profession.getString(2);
                        break;
                    }
                } while (cursor_profession.moveToNext());
            }
            //get SchoolName
            if (cursor_school != null && cursor_school.moveToFirst()) {
                do {
                    if (student.getSchool_id().equals(cursor_school.getString(0))) {
                        schoolName = cursor_school.getString(1);
                        break;
                    }
                } while (cursor_school.moveToNext());
            }

            //getStudent_lesson
            if (cursor_student_lesson != null && cursor_student_lesson.moveToFirst()) {
                do {
                    if (student.getStu_id().equals(cursor_student_lesson.getString(1))) {
                        Student_Lesson student_lesson = new Student_Lesson(cursor_student_lesson.getString(0),
                                cursor_student_lesson.getString(1),
                                cursor_student_lesson.getString(2));
                        student_lessonList.add(student_lesson);
                    }
                } while (cursor_student_lesson.moveToNext());
            }
        }
    }

    /**
     * Configure listView
     */
    private void listViewSet() {
        list_listView = new ArrayList<>();
        for (Student_Lesson student_lesson : student_lessonList) {

            for (Lesson lesson : lessonList) {
                if (lesson.getLes_id().equals(student_lesson.getLes_id())) {
                    list_listView.add(lesson);
                }
            }

        }

        listViewHome_lessonAdapter = new ListViewHome_LessonAdapter(list_listView, getLayoutInflater());
        //Gets the listview control
        listView = findViewById(R.id.list_item_home_lesson);
        //Setting the adapter for listview
        listView.setAdapter(listViewHome_lessonAdapter);

        //Long press event of listview
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                ListView listView = (ListView) adapterView;
                //Gets the ID of the listview that is pressed for a long time
                int id = listView.getId();

                //Judge by ID
                switch (id) {
                    case R.id.list_item_home_lesson:
                        //Set the hidden modify delete button to display
                        findViewById(R.id.layout_upd_del_home_btn_lesson).setVisibility(View.VISIBLE);
                        //Each item of listview is obtained by traversing the data
                        for (i = 0; i < lessonList.size(); i++) {
                            //Set the check box for each item to display
                            listViewHome_lessonAdapter.getIsVisibileMap().put(i, CheckBox.VISIBLE);
                        }
                        //Re render listview
                        listViewHome_lessonAdapter.notifyDataSetChanged();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    private void setText() {
        textView_studentName.setText(student.getStu_name());
        textView_professionName.setText(professionName);
        textView_addressName.setText(schoolName);
    }

    private void selectAll() {
        boolean result = false;
        int len = list_listView.size();

        for (int i = 0; i < len; i++) {

            if (!(boolean) listViewHome_lessonAdapter.getIsSelectedMap().get(i)) {
                result = true;
            }
        }
        if (result) {
            for (int i = 0; i < len; i++) {
                listViewHome_lessonAdapter.getIsSelectedMap().put(i, true);

            }
            btn_selectAll.setText("Totally not");
        } else {

            for (int i = 0; i < len; i++) {
                listViewHome_lessonAdapter.getIsSelectedMap().put(i, false);
            }
            btn_selectAll.setText("Select All");
        }

        listViewHome_lessonAdapter.notifyDataSetChanged();
    }

    private void delete() {
        alertDialog = new AlertDialog.Builder(this)
                .setTitle(" Are you sure to delete？")
                .setMessage("Are you sure you want to delete the selected information")
                .setPositiveButton("determine",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                int len = list_listView.size();
                                for (int j = len - 1; j >= 0; j--) {
                                    Boolean value = (Boolean) listViewHome_lessonAdapter
                                            .getIsSelectedMap().get(j);

                                    if (value) {
                                        ContentResolver resolver = getContentResolver();
                                        Uri uri = Uri.parse("content://provider.student_LessonProvider/student_lesson/");
                                        resolver.delete(uri, student_lessonList.get(j).getSl_id(), null);
                                        list_listView.remove(j);
                                        listViewHome_lessonAdapter.getIsSelectedMap()
                                                .put(j, false);
                                    }
                                }

                                listViewHome_lessonAdapter.notifyDataSetChanged();
                                alertDialog.cancel();
                            }
                        }).setNegativeButton("cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                alertDialog.cancel();

                            }
                        }).create();
        alertDialog.show();
    }

    private void cancel() {
        findViewById(R.id.layout_upd_del_home_btn_lesson).setVisibility(View.INVISIBLE);

        for (int i = 0; i < list_listView.size(); i++) {

            listViewHome_lessonAdapter.getIsVisibileMap().put(i, CheckBox.INVISIBLE);
        }
        listViewHome_lessonAdapter.notifyDataSetChanged();
    }

    private void update() {

        int count = 0;
        int position = 0;

        for (int i = 0; i < list_listView.size(); i++) {
            if ((boolean) listViewHome_lessonAdapter.getIsSelectedMap().get(i)) {
                count++;
                position = i;
            }
        }

        if (count < 2 && count > 0) {
            Intent intent = new Intent(StudentMainActivity.this, UpdateLesson_StudentActivity.class);
            Bundle bundle = new Bundle();

            bundle.putString("les_id", list_listView.get(position).getLes_id());
            bundle.putString("stu_id", student.getStu_id());
            intent.putExtras(bundle);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Only one item can be selected for modification", Toast.LENGTH_SHORT).show();
        }
        listViewHome_lessonAdapter.notifyDataSetChanged();
    }


}
