package com.lesson.lessonstudent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.lesson.adapter.SpinnerStudent_LessonAdapter;
import com.lesson.entity.Lesson;
import com.lesson.entity.Student;
import com.lesson.entity.Student_Lesson;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UpdateLesson_StudentActivity extends AppCompatActivity {

    private Bundle bundle;

    private Spinner spinner;
    private Button btn_upd;

    private Student_Lesson student_lesson;
    private Student student;
    private List<Lesson> lessons;

    private Cursor cursor_student_lesson;
    private Cursor cursor_lesson;
    private Cursor cursor_student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_lesson__student);

        init();
        spinnserInit();

    }
    /**
     * Initializing global objects
     */
    private void init(){
        bundle=this.getIntent().getExtras();
        student_lesson=new Student_Lesson(null,
                bundle.getString("stu_id"),
                bundle.getString("les_id")
                );

        btn_upd=findViewById(R.id.btn_lesson_upd);
        spinner=findViewById(R.id.spin_lesson_student_upd);

        ContentResolver resolver = getContentResolver();
        Uri uri = Uri.parse("content://provider.student_LessonProvider/student_lesson/");
        cursor_student_lesson = resolver.query(uri, null, null, null, null, null);

        if (cursor_student_lesson!=null && cursor_student_lesson.moveToFirst()){
            do {
                if (cursor_student_lesson.getString(1).equals(student_lesson.getStu_id())
                && cursor_student_lesson.getString(2).equals(student_lesson.getLes_id())){
                    student_lesson.setSl_id(cursor_student_lesson.getString(0));
                }
            }while (cursor_student_lesson.moveToNext());
        }


        uri = Uri.parse("content://provider.studentProvider/student/");
        cursor_student = resolver.query(uri, null, null, null, null, null);
        if (cursor_student!=null && cursor_student.moveToFirst()){
            do {
                if (cursor_student.getString(0).equals(student_lesson.getStu_id())) {
                    student = new Student(cursor_student.getString(0),
                            cursor_student.getString(1),
                            cursor_student.getString(2),
                            cursor_student.getString(3),
                            cursor_student.getString(4),
                            cursor_student.getString(5));
                }
            }while (cursor_student.moveToNext());
        }

        lessons=new ArrayList<>();
        uri = Uri.parse("content://provider.lessonProvider/lesson/");
        cursor_lesson = resolver.query(uri, null, null, null, null, null);
        if (cursor_lesson!=null && cursor_lesson.moveToFirst()){
            do {
                if (student.getSchool_id().equals(cursor_lesson.getString(2))
                        &&student.getPro_id().equals(cursor_lesson.getString(3))){

                    lessons.add(new Lesson(cursor_lesson.getString(0),
                            cursor_lesson.getString(1),
                            cursor_lesson.getString(2),
                            cursor_lesson.getString(3)));
                }
            }while (cursor_lesson.moveToNext());
        }


    }

    /**
     * Initializing spinner
     */
    private void spinnserInit(){
        SpinnerStudent_LessonAdapter adapter = new SpinnerStudent_LessonAdapter(lessons, this);

        spinner.setAdapter(adapter);

        int i=0;
        for (;i<lessons.size();i++){
            if (lessons.get(i).getLes_id().equals(student_lesson.getLes_id())){
                break;
            }
        }
        spinner.setSelection(i);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                btn_upd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        student_lesson.setLes_id(lessons.get(position).getLes_id());
                        Uri uri = Uri.parse("content://provider.student_LessonProvider/student_lesson/");
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put("sl_id", student_lesson.getSl_id());
                        values.put("stu_id",student_lesson.getStu_id());
                        values.put("les_id",student_lesson.getLes_id());

                        resolver.update(uri, values,null,null);

                        //Display new success information
                        Toast.makeText(getApplication(), "update Successed", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(UpdateLesson_StudentActivity.this,StudentMainActivity.class));
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}
