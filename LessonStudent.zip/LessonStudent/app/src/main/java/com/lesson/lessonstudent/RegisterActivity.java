package com.lesson.lessonstudent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.UUID;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    private Button btn_regist;
    private EditText editText_username;
    private EditText editText_password;
    private EditText editText_ensuerPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //Hide the head of the app
        this.getSupportActionBar().hide();
        init();

        btn_regist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regist();
            }
        });
    }

    private void init() {
        btn_regist = findViewById(R.id.btn_regist_reg);
        editText_username = findViewById(R.id.username_reg);
        editText_password = findViewById(R.id.password_reg);
        editText_ensuerPassword = findViewById(R.id.ensurePassword_reg);
    }

    public void regist() {
        //Gets the text content of the control
        String username_edit = editText_username.getText().toString();
        String passname_edit = editText_password.getText().toString();
        String ensurePass_edit = editText_ensuerPassword.getText().toString();
        //Regular expressions are used to determine whether the user name and password meet the criteria
        //User name; can use letters and case letters, numbers 0-9 should be within 2-7 characters
        //Password: can use letters and case letters, numbers 0-9 should be within 6-16 characters
        String usernameReg = "^[a-zA-Z_][a-zA-Z0-9_]{2,7}$";
        String passwordReg = "^[a-zA-Z_][a-zA-Z0-9_]{6,16}$";

        //Judge whether the text is regular or not
        if (!Pattern.matches(usernameReg, username_edit)) {
            editText_username.setError("The format of the user name is wrong. It should consist of 2-7 digits of upper and lower case letters and numbers");
        }
        if (!Pattern.matches(passwordReg, passname_edit)) {
            editText_password.setError("The password format is wrong, which should be composed of 6-16 digits of upper and lower case letters and numbers");
        } else {
            //Determine whether the password text is consistent with the password text
            if (ensurePass_edit.equals(passname_edit)) {
                //Generate ID number randomly by UUID
                String id = UUID.randomUUID().toString();
                Uri uri = Uri.parse("content://provider.stuuProvider/stuu/");
                ContentResolver resolver = getContentResolver();
                ContentValues values = new ContentValues();
                values.put("id", id);
                values.put("username", username_edit);
                values.put("password", passname_edit);
                values.put("stu_id", "");

                //Register judgment function
                if (registJudge(values)) {
                    uri = resolver.insert(uri, values);
                    if (uri != null) {
                        Toast.makeText(getApplicationContext(), "regist success!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                    }
                } else {
                    editText_username.setError("Username already exists");
                }
            } else {
                editText_ensuerPassword.setError(" password input is inconsistent");
            }
        }
    }

    /**
     * Registration judgment
     *
     */
    public boolean registJudge(ContentValues values) {
        boolean result = true;
        ContentResolver resolver = getContentResolver();

        Uri uri = Uri.parse("content://provider.stuuProvider/stuu/");
        Cursor cursor = resolver.query(uri, null, null, null, null, null);
        for (; ; ) {
            if (cursor.moveToNext()) {

                System.out.println(cursor.getString(1));
                if (cursor.getString(1).equals(values.get("username"))) {
                    result = false;
                    cursor.moveToFirst();
                    cursor.close();
                    break;
                }
            } else {

                break;
            }
        }
        cursor.close();
        return result;
    }


}

